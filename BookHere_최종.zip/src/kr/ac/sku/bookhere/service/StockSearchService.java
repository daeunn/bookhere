package kr.ac.sku.bookhere.service;

import java.util.Hashtable;

import kr.ac.sku.bookhere.vo.GstockVO;


public interface StockSearchService {
	public Hashtable<String, String> kyobo(String isbn); 
	
	public Hashtable<String, String> bandi(String isbn);
	
	public Hashtable<String, String> ypbooks(String isbn);
	
	public Hashtable<String, String> aladin(String isbn);
	
	public Hashtable<String, String> local(String isbn);
	
	public Hashtable<String, String> kyoboStockList(String isbn);
	
	public Hashtable<String, String> bandiStockList(String isbn);
	
	public Hashtable<String, String> ypStockList(String isbn);
	
	public Hashtable<String, String> aladinStockList(String isbn);
	
	public GstockVO hasStock(GstockVO vo);
}
