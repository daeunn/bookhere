package kr.ac.sku.bookhere.service;


import java.util.List;

import kr.ac.sku.bookhere.vo.BookVO;


public interface BookService {
	public int updateBook(String isbn) throws Exception; 

}
