package kr.ac.sku.bookhere.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import kr.ac.sku.bookhere.vo.MemberVO;
import kr.ac.sku.bookhere.vo.SearchVO;

public interface MemberService {
	// dao.deleteMember
	public int deleteMember(String id);

	// dao.insertMember
	public int insertMember(MemberVO vo);

	// dao.selectMember
	public MemberVO selectMember(String id);

	// dao.selectOwner
	public List<MemberVO> selectOwner();

	// dao.selectMemberList
	public List<MemberVO> selectMemberList();

	// dao.memberList
	public List<MemberVO> memberList(SearchVO vo);

	// dao.selectMemberList
	public List<MemberVO> selectTopMemberList();

	// dao.updateMember
	public int updateMember(MemberVO vo);

	// 파일업로드
	public String fileUpload(MemberVO vo, HttpServletRequest req);

	// dao.updateOwner
	public int updateLikeCount(String id);

	//총 회원수
	public int listTotal();
	
	public int updateOwner0(String id);

	// dao.updateOwner
	public int updateOwner1(String id);

	// dao.updateOwner
	public int updateOwner2(String id);

	// dao.updateOwner
	public int updateOwner3(String id);
}