package kr.ac.sku.bookhere.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.sku.bookhere.dao.BookStoreDAO;
import kr.ac.sku.bookhere.dao.GstockDAO;
import kr.ac.sku.bookhere.vo.BookStoreVO;
import kr.ac.sku.bookhere.vo.GstockVO;
import kr.ac.sku.bookhere.vo.OwnerVO;

@Service("bookstoreService")
public class BookStoreServiceImpl implements BookStoreService {

	@Autowired
	BookStoreDAO bookstoreDAO;

	@Autowired
	GstockDAO gstockDAO;
	
	@Autowired
	StockSearchService stockSearchService;

	@Override
	public List<BookStoreVO> kyoboStoreList() throws RuntimeException {
		return bookstoreDAO.kyoboStoreList();
	}

	@Override
	public List<BookStoreVO> bandiStoreList() throws RuntimeException {
		return bookstoreDAO.bandiStoreList();
	}

	@Override
	public List<BookStoreVO> ypStoreList() throws RuntimeException {
		return bookstoreDAO.ypStoreList();
	}

	@Override
	public List<BookStoreVO> aladinStoreList() throws RuntimeException {
		return bookstoreDAO.aladinStoreList();
	}

	@Override
	public int insertBookstore(BookStoreVO vo) throws RuntimeException {
		return bookstoreDAO.insertBookstore(vo);
	}

	@Override
	public List<BookStoreVO> gbookstoreList() throws RuntimeException {
		return bookstoreDAO.gbookstoreList();
	}

	@Override
	public List<BookStoreVO> bookstoreList() throws RuntimeException {
		return bookstoreDAO.bookstoreList();
	}

	@Override
	public List<BookStoreVO> selectBookstore(String searchTxt) throws RuntimeException {
		return bookstoreDAO.selectBookstore2(searchTxt);
	}

	@Override
	public int countAllBookstore() throws RuntimeException {
		return bookstoreDAO.countAllBookstore();
	}

	@Override
	public int countBookstore() throws RuntimeException {
		return bookstoreDAO.countBookstore();
	}

	@Override
	public int countGBookstore() throws RuntimeException {
		return bookstoreDAO.countGBookstore();
	}

	@Override
	public int deleteBookstore(String branchid) throws RuntimeException {
		return bookstoreDAO.deleteBookstore(branchid);
	}

	@Override
	public BookStoreVO selectOneBookstore(String branchid) {
		return bookstoreDAO.selectOneBookstore(branchid);
	}

	@Override
	public String fileUpload(BookStoreVO vo, HttpServletRequest req) {

		String path = req.getRealPath("/upload");
		String upPath = path + "\\" + vo.getBookstorefile().getOriginalFilename();
		File f = new File(upPath);

		try {
			vo.getBookstorefile().transferTo(f);
		} catch (IllegalStateException | IOException e) {
			e.printStackTrace();
		}
		vo.setPic(vo.getBookstorefile().getOriginalFilename());

		return vo.getPic();
	}

	@Override
	public List<OwnerVO> ownerandbookstore() throws RuntimeException {
		return bookstoreDAO.ownerandbookstore();
	}

	@Override
	public int updateWebstie(OwnerVO vo) {
		return bookstoreDAO.updateWebstie(vo);
	}

	@Override
	public BookStoreVO getLatLon(BookStoreVO vo) {
		return bookstoreDAO.getLatLon(vo);
	}

	@Override
	public List<BookStoreVO> allbookstoreList() throws RuntimeException {
		return bookstoreDAO.allbookstoreList();
	}

	@Override
	public Map<String, String> selectDistance(String isbn) throws RuntimeException {

		List<BookStoreVO> all_list = bookstoreDAO.allBookstoreList();
		List<Double> list = new ArrayList<Double>();
		Hashtable<Double, String> ht = new Hashtable<Double, String>();
		Map<String, String> hm = new LinkedHashMap<String, String>(); // 순서 유지
		double current_lat = 37.61607556696648;
		double current_lon = 127.01187925254634;
		double theta, dist;
		for (int i = 0; i < all_list.size(); i++) {

			double latitude = Float.parseFloat(all_list.get(i).getLatitude());
			double longitude = Float.parseFloat(all_list.get(i).getLongitude());

			theta = current_lon - longitude;
			// 도(degree)값을 라디언(radian)으로 변환
			double rad1 = (double) (current_lat * Math.PI / (double) 180d);
			double rad2 = (double) (latitude * Math.PI / (double) 180d);
			double rad3 = (double) (theta * Math.PI / (double) 180d);
			dist = Math.sin(rad1) * Math.sin(rad2) + Math.cos(rad1) * Math.cos(rad2) * Math.cos(rad3);
			dist = Math.acos(dist);
			dist = (double) (dist * (double) 180d / Math.PI);

			dist = dist * 60 * 1.1515;
			dist = dist * 1.609344;
			double distance = Double.parseDouble(String.format("%.2f", dist));

			String str = all_list.get(i).getStorename() + " " + all_list.get(i).getBranchname(); // 서점명+지점명
			ht.put(distance, str);
			list.add(distance);
			Collections.sort(list);
		}

		for (int i = 0; i < list.size(); i++) {
			String locate = Double.toString(list.get(i)) + "km";

			String fullname = ht.get(list.get(i));
			String[] full = fullname.split(" ");
			String storename = full[0];
			String branchname = full[1];
			GstockVO vo = new GstockVO();
			vo.setIsbn(isbn);
			vo.setStorename(storename);
			vo.setBranchname(branchname);
			try {
				if(storename.equals("동네서점")){
					Hashtable<String, String> ht2 = new Hashtable<String, String>();
					ht2 = stockSearchService.local(isbn);
					if(!ht2.get(branchname).equals(null))
						hm.put(ht.get(list.get(i)),	ht2.get(branchname) + " │ " + locate); // (지점명,거리(km))
				}
				else
					hm.put(ht.get(list.get(i)), gstockDAO.hasStock(vo).getStock() + "권" + " │ " + locate); // (지점명,거리(km))
			} catch (NullPointerException e) {
			}
		}
		return hm;
	}

}