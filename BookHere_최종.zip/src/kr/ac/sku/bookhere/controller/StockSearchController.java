package kr.ac.sku.bookhere.controller;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.ac.sku.bookhere.dao.BookDAO;
import kr.ac.sku.bookhere.dao.GstockDAO;
import kr.ac.sku.bookhere.service.BookService;
import kr.ac.sku.bookhere.service.BookStoreService;
import kr.ac.sku.bookhere.service.StockSearchService;
import kr.ac.sku.bookhere.thread.StockSearchThread;
import kr.ac.sku.bookhere.vo.BookVO;
import kr.ac.sku.bookhere.vo.GstockVO;

@Controller
public class StockSearchController extends Thread {
	@Autowired
	StockSearchService stockSearchService;

	@Autowired
	BookStoreService bookstoreService;

	@Autowired
	BookService bookService;

	@Autowired
	BookDAO bookDAO;
	
	@Autowired
	GstockDAO gstockDAO;

	@RequestMapping("stockSearch")
	public String StockSearch(String isbn, Model model) throws Exception {

		try {
			if (!bookDAO.selectBook(isbn).equals(null) || bookDAO.selectBook(isbn) != null) {
				model.addAttribute("kyoboStockList", stockSearchService.kyoboStockList(isbn));
				model.addAttribute("bandiStockList", stockSearchService.bandiStockList(isbn));
				model.addAttribute("ypStockList", stockSearchService.ypStockList(isbn));
				model.addAttribute("aladinStockList", stockSearchService.aladinStockList(isbn));
			}
		} catch (NullPointerException e) {

			try {
				bookDAO.insertBook(isbn);
			} catch (DuplicateKeyException e1) {
			}

			StockSearchThread kyobo = new StockSearchThread(1, stockSearchService, isbn);
			StockSearchThread bandi = new StockSearchThread(2, stockSearchService, isbn);
			StockSearchThread ypbooks = new StockSearchThread(3, stockSearchService, isbn);
			StockSearchThread aladin = new StockSearchThread(4, stockSearchService, isbn);

			kyobo.start();
			bandi.start();
			ypbooks.start();
			aladin.start();

			kyobo.join(); // join을 사용하여 동시에 시작
			bandi.join();
			ypbooks.join();
			aladin.join();

			model.addAttribute("kyoboStockList", kyobo.toController());
			model.addAttribute("bandiStockList", bandi.toController());
			model.addAttribute("ypStockList", ypbooks.toController());
			model.addAttribute("aladinStockList", aladin.toController());
		}

		// 동네서점 재고
		model.addAttribute("localStockList", stockSearchService.local(isbn));
		
		// 지도에 매장 정보 뿌리기
		model.addAttribute("kyoboStoreList", bookstoreService.kyoboStoreList());
		model.addAttribute("bandiStoreList", bookstoreService.bandiStoreList());
		model.addAttribute("ypStoreList", bookstoreService.ypStoreList());
		model.addAttribute("aladinStoreList", bookstoreService.aladinStoreList());
		model.addAttribute("localStoreList", bookstoreService.bookstoreList());
		
		model.addAttribute("prodidbookcd", bookDAO.prodidbookcd(isbn));

		bookService.updateBook(isbn);
		model.addAttribute("distance",bookstoreService.selectDistance(isbn));
		return "single-product";
	}
	
	@RequestMapping("updateStock")
	public String UpdateStock() throws Exception {
		Hashtable<String, String> ht = new Hashtable<String, String>();
		List<BookVO> allIsbn = bookDAO.selectAllIsbn();
		GstockVO vo = new GstockVO();

		int count = 0;
		for (int i = 0; i < allIsbn.size(); i++) {
			String isbn = allIsbn.get(i).getIsbn();
			
			StockSearchThread kyobo = new StockSearchThread(1, stockSearchService, isbn);
			StockSearchThread ypbooks = new StockSearchThread(2, stockSearchService, isbn);
			StockSearchThread bandi = new StockSearchThread(3, stockSearchService, isbn);
			StockSearchThread aladin = new StockSearchThread(4, stockSearchService, isbn);

			kyobo.start();
			ypbooks.start();
			bandi.start();
			aladin.start();

			kyobo.join(); // join을 사용하여 동시에 시작
			ypbooks.join();
			bandi.join();
			aladin.join();

			
			ht = kyobo.toController();
			Enumeration en1 = ht.keys();
			while(en1.hasMoreElements()){
				String key = en1.nextElement().toString();
				vo.setIsbn(isbn);
				vo.setBranchname(key);
				vo.setStorename("교보문고");
				String stock = ht.get(key).replaceAll("권", "");
				vo.setStock(stock);
				gstockDAO.updateGStock(vo);
			}
			
			ht = bandi.toController();
			Enumeration en2 = ht.keys();
			while(en2.hasMoreElements()){
				String key = en2.nextElement().toString();
				vo.setIsbn(isbn);
				vo.setBranchname(key);
				vo.setStorename("반디앤루니스");
				String stock = ht.get(key).replaceAll("권", "");
				vo.setStock(stock);
				gstockDAO.updateGStock(vo);
			}
			
			
			ht = ypbooks.toController();
			Enumeration en3 = ht.keys();
			while(en3.hasMoreElements()){
				String key = en3.nextElement().toString();
				vo.setIsbn(isbn);
				vo.setBranchname(key);
				vo.setStorename("영풍문고");
				String stock = ht.get(key).replaceAll("권", "");
				vo.setStock(stock);
				gstockDAO.updateGStock(vo);
			}
			
			
			ht = aladin.toController();
			Enumeration en4 = ht.keys();
			while(en4.hasMoreElements()){
				String key = en4.nextElement().toString();
				vo.setIsbn(isbn);
				vo.setBranchname(key);
				vo.setStorename("알라딘");
				String stock = ht.get(key).replaceAll("권", "");
				vo.setStock(stock);
				gstockDAO.updateGStock(vo);
			}			
			System.out.println(isbn);
			count++;
		}
		System.out.println("총 "+count+"권 업데이트");
		return "redirect:/index";
	}

}