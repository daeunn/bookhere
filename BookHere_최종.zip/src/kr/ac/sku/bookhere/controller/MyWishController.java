package kr.ac.sku.bookhere.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.ac.sku.bookhere.service.MyWishService;
import kr.ac.sku.bookhere.vo.BookStoreVO;
import kr.ac.sku.bookhere.vo.MyBookVO;
import kr.ac.sku.bookhere.vo.MyWishInfoVO;
import kr.ac.sku.bookhere.vo.MyWishVO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyWishController {
	@Autowired
	MyWishService mywishService;


	// insert
	@RequestMapping(value = "MyWishInsert")
	@ResponseBody
	public void MyWishInsert(HttpServletRequest request) throws IOException {
		MyWishVO vo = new MyWishVO();
		vo.setId(request.getParameter("id"));
		vo.setIsbn(request.getParameter("isbn"));
		try{
			mywishService.insertMyWish(vo);
		}catch(DuplicateKeyException e){

		}

	}

	// LIST
	@RequestMapping("MyWishList")
	public String MyWishList(@RequestParam("id")String id,Model model,MyWishVO vo) {
		if(id!=null&&!"".equals(id)){
			List<MyWishInfoVO> mywishlist = mywishService.selectMyWishList(id);
			model.addAttribute("mywishList", mywishlist);
			List<MyWishInfoVO> topwishlist = mywishService.selectTopWishList();
			model.addAttribute("topwishList", topwishlist);
			return "wishlist";
		}else
			return "redirect:/loginPage";
	}	
	
	// DELETE
	@RequestMapping("MyWishDelete")
	public String MyBookDelete(MyWishVO vo) {

		mywishService.deleteMyWish(vo);
		String id =vo.getId();
		return "redirect:/MyWishList?id="+id;

	}





}
