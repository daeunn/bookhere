package kr.ac.sku.bookhere.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import kr.ac.sku.bookhere.service.BookShelfService;
import kr.ac.sku.bookhere.service.MemberService;
import kr.ac.sku.bookhere.vo.BookShelfVO;
import kr.ac.sku.bookhere.vo.MemberVO;
import kr.ac.sku.bookhere.vo.PageVO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.ac.sku.bookhere.vo.SearchVO;


@Controller
public class BookShelfController {

	@Autowired
	MemberService memberService;

	@Autowired
	BookShelfService bookshelfService;

	// paging
	public PageVO makePageVO(Integer page, int totalRows) {

		PageVO pageInfo = new PageVO();
		int rowsPerPage = 9; 
		int pagesPerBlock = 5;  //블럭당 페이지 수
		if (page == null) page = 0;
		if(page  == 0) page = 1; 
		int currentPage = page; 
		int currentBlock = 0; 
		if (currentPage % pagesPerBlock == 0) {
			currentBlock = currentPage / pagesPerBlock;
		} else { 
			currentBlock = currentPage / pagesPerBlock + 1;
		}
		int startRow = (currentPage - 1) * rowsPerPage + 1; // ���۸�ϰ�����
		int endRow = currentPage * rowsPerPage;


		int totalPages = 0;
		if (totalRows % rowsPerPage == 0) {
			totalPages = totalRows / rowsPerPage;
		} else {
			totalPages = totalRows / rowsPerPage + 1;
		}
		int totalBlocks = 0;
		if (totalPages % pagesPerBlock == 0) {
			totalBlocks = totalPages / pagesPerBlock;
		} else {
			totalBlocks = totalPages / pagesPerBlock + 1;
		}

		pageInfo.setCurrentPage(currentPage);
		pageInfo.setCurrentBlock(currentBlock);
		pageInfo.setRowsPerPage(rowsPerPage);
		pageInfo.setPagesPerBlock(pagesPerBlock);
		pageInfo.setStartRow(startRow);
		pageInfo.setEndRow(endRow);
		pageInfo.setTotalRows(totalRows);
		pageInfo.setTotalPages(totalPages);
		pageInfo.setTotalBlocks(totalBlocks);
		return pageInfo;
	}

	// select 책장 
	@RequestMapping("bookshelfList")
	public String BookshelfList(Model model,Integer page,SearchVO vo){

		int totalRows = memberService.listTotal();
		PageVO pageInfo = makePageVO(page, totalRows);
		vo.setBegin(String.valueOf(pageInfo.getStartRow()));
		vo.setEnd(String.valueOf(pageInfo.getEndRow()));
		List<MemberVO> memberList = memberService.memberList(vo);
		model.addAttribute("memberList", memberList);
		model.addAttribute("pageInfo", pageInfo);
		List<MemberVO> topmemberlist = memberService.selectTopMemberList();
		model.addAttribute("topMemberList",topmemberlist);
		return "bookshelfList";

	}
	
	// 검색 후 책장 list
	@RequestMapping("searchBookShelf")
	public String searchBookShelf(Model model,Integer page,SearchVO vo ){

		int totalRows = memberService.listTotal();
		PageVO pageInfo = makePageVO(page, totalRows);
		vo.setBegin(String.valueOf(pageInfo.getStartRow()));
		vo.setEnd(String.valueOf(pageInfo.getEndRow()));
		List<BookShelfVO> searchlist = bookshelfService.searchList(vo);
		model.addAttribute("memberList",searchlist);
		model.addAttribute("pageInfo", pageInfo);
		model.addAttribute("vo", vo);
		List<MemberVO> topmemberlist = memberService.selectTopMemberList();
		model.addAttribute("topMemberList",topmemberlist);

		return "bookshelfList";

	}
	

	//update like count
	@RequestMapping("LikeCountUpdate")
	public String LikeCountUpdate(Model model,String id) {
		memberService.updateLikeCount(id);
		return "redirect:/bookshelfList";
		
	}


	//update like count2
	@RequestMapping("LikeCountUpdate2")
	public String LikeCountUpdate2(@RequestParam("id") String session,Model model,String id) {
		if(session!=null&&!"".equals(session)){
		memberService.updateLikeCount(id);
		return "redirect:/MyBookSelect?id="+id;}
		else
			 return "redirect:/loginPage";
	}
	

	//update like count3 - mybook에서 누르 like는
	@RequestMapping("LikeCountUpdate3")
	public String LikeCountUpdate3(Model model,String id) {
		memberService.updateLikeCount(id);
		return "redirect:/MyBookSelect?id="+id;
		
	}


}
