package kr.ac.sku.bookhere.vo;

public class SearchVO {
	// �˻������� �Ѿ�� �Ķ���Ϳ� ���� �ؾ� �Ѵ�. begin,end�� ���߿�.......
	private String searchType,searchValue, begin, end;

	public String getSearchType() {
		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}

	public String getSearchValue() {
		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	public String getBegin() {
		return begin;
	}

	public void setBegin(String begin) {
		this.begin = begin;
	}

	public String getEnd() {
		return end;
	}

	public void setEnd(String end) {
		this.end = end;
	}

	@Override
	public String toString() {
		return "SearchVO [searchType=" + searchType + ", searchValue="
				+ searchValue + ", begin=" + begin + ", end=" + end + "]";
	}
	
}

