package kr.ac.sku.bookhere.vo;

public class GstockVO {
	private int gstock_seq;
	private String storename;
	private String branchname;
	private String isbn;
	private String stock;
	
	
	public int getGstock_seq() {
		return gstock_seq;
	}
	public void setGstock_seq(int gstock_seq) {
		this.gstock_seq = gstock_seq;
	}
	public String getStorename() {
		return storename;
	}
	public void setStorename(String storename) {
		this.storename = storename;
	}
	public String getBranchname() {
		return branchname;
	}
	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	
	public String getStock() {
		return stock;
	}
	public void setStock(String stock) {
		this.stock = stock;
	}
	@Override
	public String toString() {
		return "GstockVO [storename=" + storename + ", branchname="
				+ branchname + ", isbn=" + isbn + ", stock=" + stock + "]";
	}
	
	
}
