package kr.ac.sku.bookhere.dao;

import java.util.List;

import kr.ac.sku.bookhere.vo.GstockVO;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("gstockDAO")
public class GstockDAOImpl implements GstockDAO {
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public int insertKyoboStock(GstockVO vo) throws RuntimeException {
		return sqlSession.insert("kr.ac.sku.bookhere.Gstock.insertKyoboStock", vo);
	}

	@Override
	public int insertBandiStock(GstockVO vo) throws RuntimeException {
		return sqlSession.insert("kr.ac.sku.bookhere.Gstock.insertBandiStock", vo);
	}

	@Override
	public int insertYpStock(GstockVO vo) throws RuntimeException {
		return sqlSession.insert("kr.ac.sku.bookhere.Gstock.insertYpStock", vo);
	}

	@Override
	public int insertAladinStock(GstockVO vo) throws RuntimeException {
		return sqlSession.insert("kr.ac.sku.bookhere.Gstock.insertAladinStock", vo);
	}

	@Override
	public List<GstockVO> kyoboStockList(String isbn) throws RuntimeException {
		return sqlSession.selectList("kr.ac.sku.bookhere.Gstock.kyoboStockList",isbn);
	}

	@Override
	public List<GstockVO> bandiStockList(String isbn) throws RuntimeException {
		return sqlSession.selectList("kr.ac.sku.bookhere.Gstock.bandiStockList",isbn);
	}

	@Override
	public List<GstockVO> ypStockList(String isbn) throws RuntimeException {
		return sqlSession.selectList("kr.ac.sku.bookhere.Gstock.ypStockList",isbn);
	}

	@Override
	public List<GstockVO> aladinStockList(String isbn) throws RuntimeException {
		return sqlSession.selectList("kr.ac.sku.bookhere.Gstock.aladinStockList",isbn);
	}

	@Override
	public GstockVO hasStock(GstockVO vo) throws RuntimeException {
		return sqlSession.selectOne("kr.ac.sku.bookhere.Gstock.hasStock", vo);
	}
	
	@Override
	public GstockVO updateGStock(GstockVO vo) throws RuntimeException {
		return sqlSession.selectOne("kr.ac.sku.bookhere.Gstock.updateGStock", vo);
	}
	
}
