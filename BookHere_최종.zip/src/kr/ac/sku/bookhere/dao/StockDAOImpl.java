package kr.ac.sku.bookhere.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.sku.bookhere.vo.GstockVO;
import kr.ac.sku.bookhere.vo.StockVO;

@Repository("stockDAO")
public class StockDAOImpl implements StockDAO {
   @Autowired
   private SqlSession sqlSession;
   
   @Override
   public int insertStock(List<StockVO> list) throws RuntimeException {
      int count = 0;
      for(StockVO vo : list) {
         count = sqlSession.insert("kr.ac.sku.bookhere.Stock.insertStock", vo);
        }
      return count;
   }
   
   @Override
	public int deleteStock(int branchid) throws RuntimeException {
		return sqlSession.delete("kr.ac.sku.bookhere.Stock.deleteStock", branchid);
	}
   
   @Override
	public List<StockVO> selectStock(int branchid) throws RuntimeException {
		return sqlSession.selectList("kr.ac.sku.bookhere.Stock.selectStockList", branchid);
	}
   
   @Override
	public List<GstockVO> localStock(String isbn) throws RuntimeException {
		return sqlSession.selectList("kr.ac.sku.bookhere.Stock.selectLocalStock", isbn);
	}
}