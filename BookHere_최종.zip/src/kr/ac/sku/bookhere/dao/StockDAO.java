package kr.ac.sku.bookhere.dao;

import java.util.List;

import kr.ac.sku.bookhere.vo.GstockVO;
import kr.ac.sku.bookhere.vo.StockVO;

public interface StockDAO {
   // INSERT
   public int insertStock(List<StockVO> list) throws RuntimeException;
   
   // DELETE
   public int deleteStock(int branchid) throws RuntimeException;
   
   // SELECT
   public List<StockVO> selectStock(int branchid) throws RuntimeException;
   
   // SELECT local
   
   public List<GstockVO> localStock(String isbn) throws RuntimeException;
}