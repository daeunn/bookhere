package kr.ac.sku.bookhere.dao;

import java.util.List;

import kr.ac.sku.bookhere.vo.GstockVO;
public interface GstockDAO {

	// INSERT KYOBO STOCK
	public int insertKyoboStock(GstockVO vo) throws RuntimeException;

	// INSERT BANDI STOCK
	public int insertBandiStock(GstockVO vo) throws RuntimeException;

	// INSERT YP STOCK
	public int insertYpStock(GstockVO vo) throws RuntimeException;

	// INSERT ALADIN STOCK
	public int insertAladinStock(GstockVO vo) throws RuntimeException;

	// SELECT KYOBOSTOCK
	public List<GstockVO> kyoboStockList(String isbn) throws RuntimeException;

	// SELECT BANDISTOCK
	public List<GstockVO> bandiStockList(String isbn) throws RuntimeException;

	// SELECT YPSTOCK
	public List<GstockVO> ypStockList(String isbn) throws RuntimeException;

	// SELECT ALADINSTOCK
	public List<GstockVO> aladinStockList(String isbn) throws RuntimeException;
	
	// 거리순 매장 재고 확인
	public GstockVO hasStock(GstockVO vo) throws RuntimeException;
	
	// 대형서점 재고 업데이트
	public GstockVO updateGStock(GstockVO vo) throws RuntimeException;


}
